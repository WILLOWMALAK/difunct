# difunct
Implements functions for the combined analysis of fMRI and dMRI data. 
